import java.io.*;
import java.net.*;
import java.util.*;

public class Server {
	
	public static ArrayList<ServerClient> clientList = new ArrayList<ServerClient>();
	
	private static void setPort(int port) {
		
		Scanner sc = new Scanner (System.in);
		
		try {
			ServerSocket sSocket = new ServerSocket(port);
			Socket cSocket;
			System.out.println("Server started on port: " + port);

			while (true) {
				try {
					cSocket = sSocket.accept();
					ServerClient newClient = new ServerClient(cSocket);
					clientList.add(newClient);
					System.out.println("<" + newClient.nickname + ">" + " connected. <" + cSocket.getInetAddress() + ":" + cSocket.getPort() + ">");
				}
				catch (Exception e) {
					System.out.println("Could not add client!");
				}
			}
		}
		catch (IOException e){
			System.out.println("Server could not start. Change port!");
			System.out.print("New port: ");
			port = sc.nextInt();
			setPort(port);
		}
	}


	public static void main(String[] args) {
	
		setPort(1337);
	
	}


	static class ServerClient extends Thread {
		String nickname;
	
		Socket cSocket = null;
	
		DataOutputStream oStream = null;
		DataInputStream iStream = null;
	
		public ServerClient (Socket cltSocket) {
			try {
				cSocket = cltSocket;
				iStream = new DataInputStream(cSocket.getInputStream());
				oStream = new DataOutputStream(cSocket.getOutputStream());
			}
			catch (Exception e) {
				System.out.println("Error @ ServerClient: " + e);
			}
			setNickname();
			availableCommands();
			start();
		}
	
		public void availableCommands() {
			try {
				oStream.writeUTF("Commands: \n /h - help \n /all - list all clients \n /w <nickname> <message> - whisper <nickname> <message> \n /y <message> - broadcast <message> \n /nick <nickname> - change nickname \n /q - quit");
			}
			catch (Exception e){
				System.out.println("Error @ availableCommnads: " + e);
			}
		}
	
		private boolean nicknameAvailability(String newNickname) {
			for (ServerClient client : clientList)
				if (newNickname.compareToIgnoreCase(client.nickname) == 0)
					return false;
			return true;
		}
	
		public void setNickname () {
			try {
				String name;
				oStream.writeUTF("Set nickname: ");
				name = iStream.readUTF();
				if (name == "")
					throw new IllegalArgumentException("n must be positive");
				if (nicknameAvailability(name)) {
					this.nickname = name;
					oStream.writeUTF("Your nickname is: " + name);
				}
				else {
					oStream.writeUTF("Invalid nickname. Try again!");
					setNickname();
				}
			}
			catch (Exception e) {
				System.out.println("Error @ setNickname: " + e);
			}
		}
		
		public void changeNickname(String newNickname) {
			try {
				
				
				System.out.print(this.nickname.toUpperCase() + " changed nickname to: " + newNickname.toUpperCase());
				if (nicknameAvailability(newNickname)) {
					this.nickname = newNickname;
					oStream.writeUTF("Your nickname is: " + newNickname);

				}
				else {
					oStream.writeUTF("Invalid nickname. Try again!");
					oStream.writeUTF("New nickname: ");
					newNickname = iStream.readUTF();
					changeNickname(newNickname);
				}
			}
			catch (Exception e) {
				System.out.println("Error @ setNickname: " + e);
			}
		}
	
		public void whisper(String receiver, String message) {
			Boolean ok = true;
			int x = 0;
			while (true && ok == true) {
				try {
					while (nickname.compareToIgnoreCase(receiver) == 0) {
						oStream.writeUTF("Socialize with others! ");
						listAll();
						receiver = iStream.readUTF();
					}
					for (ServerClient client : clientList) {
						if (client.nickname.compareToIgnoreCase(receiver) == 0) {
							ok = false;
							client.oStream.writeUTF(nickname.toUpperCase() + " whispered: " + message);
							break;
						}
					}
					if (ok) {
						oStream.writeUTF(receiver.toUpperCase() + " does not exist!");
						listAll();
						break;
					}
				} catch (Exception e) {
					System.out.print(e);
				}
			}
		}
	
		public void listAll() {
			try {
				oStream.writeUTF("Connected users: ");
			}
			catch (Exception e){
				System.out.println(e);
			}
			for (ServerClient client : clientList) {
				try {
					oStream.writeUTF(client.nickname);
				}
				catch (Exception e){
					System.out.println(e);
				}
			}
		}
		
		private static boolean yellMessage (ServerClient sender, String message) {
			for (ServerClient client : clientList) {
				if (client.nickname.equalsIgnoreCase(sender.nickname) == false) {
					try {
						client.oStream.writeUTF(sender.nickname + " yelled: " + message.toUpperCase());
//						client.oStream.writeUTF(message);
					}
					catch (Exception e) {
						System.out.println("Error @ yellMessage: " + e);
						return false;
					}
				}
			}
			return true;
		}
		
		public void yell (String message) {
			if (yellMessage(this, message)) {
				System.out.println("<" + this.nickname + ">" + " yelled: " + message.toUpperCase());
				try {
					oStream.writeUTF("Everybody heard you!");
				}
				catch (Exception e) {
					System.out.println("Error @ yell: " + e);
				}
			}
		}
		
		public void quit() {
			try {
				//this.oStream.close();
				//this.iStream.close();
				try {
					clientList.remove(this);
					cSocket.close();
				}
				catch (Exception e) {
					System.out.println(e);
				}
				if (this.nickname == null){
					clientList.remove(this);
				}
			}
			catch (Exception e){
				System.out.println(e);
			}
		}
		
		private String commandParser (String command) {
			String[] tmp = command.split(" ");
			if (tmp[0].equalsIgnoreCase("/w")) {
				String message = "";
				for (int i = 2; i < tmp.length; i++)
					message = message + tmp[i] + " ";
				whisper(tmp[1], message);
				return "";
			}
		
			if (tmp[0].equalsIgnoreCase("/y")) {
				String message = "";
				for (int i = 1; i < tmp.length; i++)
					message = message + tmp[i] + " ";
				yell(message);
				return "";
			}
		
			if (tmp[0].equalsIgnoreCase("/nick")) {
				changeNickname(tmp[1]);
				return "";
			}
			return command;
		}
		
		public void run() {
			String command;
			try {
				while (true) {
					command = commandParser(iStream.readUTF());
					if (command.equals("0"))
						continue;
					
					if (command.equalsIgnoreCase("/all")) {
						listAll();
						continue;
					}
					
					if (command.equalsIgnoreCase("/h")) {
						availableCommands();
						continue;
					}
				
					if (command.equalsIgnoreCase("/q")) {
						System.out.println("<" + this.nickname + ">" + " disconnected!");
						quit();
						break;
					}	
				}
			}
			catch (Exception e) {
				System.out.println("<" + this.nickname + ">" + " lost connection!");
				this.quit();
				this.stop();
				clientList.remove(this);
			}
		}
	}
}