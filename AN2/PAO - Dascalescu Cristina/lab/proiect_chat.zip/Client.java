
import java.net.*;
import java.io.*;
import java.util.*;

public class Client extends Thread {
    

	Socket cSocket;
	DataInputStream iStream;
		
	static int port;
	static String ipAddress;

	Client(Socket socket) {
		try {
			cSocket = socket;
			iStream = new DataInputStream(socket.getInputStream());
			start();
		} 
		catch (Exception e) {
			System.out.println(e);
			System.exit(1);
		}
	}

	public void run() {
		String message;
		while (true) {
			try {
				message = iStream.readUTF();
				System.out.println(message);
			} catch (Exception e) {
				System.out.println("Server shut down!");
				System.exit(1);
			}
		}
	}
		
	public static void main(String[] args) {
		String message;
		Scanner sc = new Scanner(System.in);
		Scanner anssc = new Scanner(System.in);
		Socket socket = null;
		try {
			System.out.println("shad0w? 1-Yes, 2-localhost");
			int ans = anssc.nextInt();
			if (ans == 1)
				socket = new Socket("162.243.121.242", 1337);
			else
				socket = new Socket("localhost", 1337);
			
			DataOutputStream oStream = new DataOutputStream(socket.getOutputStream());
			Client clientThread = new Client(socket);
          
			while (true) {
				message = sc.nextLine();
				oStream.writeUTF(message);
				oStream.flush();
				if (message.compareToIgnoreCase("/q") == 0) {
					break;
				}
			}
		
			clientThread.stop();
			System.out.println("Have a nice day. Bye!");
			System.exit(0);
		}
		catch (Exception e){
			System.out.println("Server offline!");
		}
	}
}
