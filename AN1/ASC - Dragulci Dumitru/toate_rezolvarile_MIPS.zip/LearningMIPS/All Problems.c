PROBLEME LUCRATE
MIPS1
{
PB1 maxim(x,y,z)
{
	.data
newline: .asciiz "\n"
.text

main:
	la $a0,newline
	li $v0,4
		syscall

	li $v0,5 # 
		syscall
	move $t0,$v0
	li $v0,5 # 
		syscall
	move $t1,$v0
	li $v0,5 # 
		syscall
	move $t2,$v0
	
	bgt $t0,$t1,ED1
	move $t0,$t1
ED1:
	bgt $t0,$t2,ED2
	move $t0,$t2
ED2:
	move $a0,$t0
	li $v0,1 
		syscall

	la $a0,newline
	li $v0,4
		syscall
li $v0,10
syscall
}

PB2 sort(x,y,z)
{
	.data
newline: .asciiz "\n"
.text

main:
	la $a0,newline
	li $v0,4
		syscall

	li $v0,5 # 
		syscall
	move $t0,$v0
	li $v0,5 # 
		syscall
	move $t1,$v0
	li $v0,5 # 
		syscall
	move $t2,$v0
	
	blt $t0,$t1,ED1
		move $t4,$t0
		move $t0,$t1
		move $t1,$t4
ED1:
	blt $t0,$t2,ED2
		move $t4,$t0
		move $t0,$t2
		move $t2,$t4
ED2:
	blt $t1,$t2,ED3
		move $t4,$t1
		move $t1,$t2
		move $t2,$t4
ED3:
	la $a0,newline
	li $v0,4
		syscall
	
	move $a0,$t0
	li $v0,1 
		syscall
		
	la $a0,newline
	li $v0,4
		syscall
		
	move $a0,$t1
	li $v0,1 
		syscall
		
	la $a0,newline
	li $v0,4
		syscall
		
	move $a0,$t2
	li $v0,1 
		syscall

	la $a0,newline
	li $v0,4
		syscall
li $v0,10
syscall
}

PB3 sum elem vector
{
	.data
vector:	.word 1,2,3,4,5,6,7,8,9,10
.text

main:
	la $t0,vector
	add $t1,$t0,40 #adresa de sfarsit
	li $t3,0 #suma
	
FOR:
	beq $t0,$t1,END_FOR
	lw $t2,($t0)
	
	add $t3,$t3,$t2
	
	addi $t0,4
	j,FOR
END_FOR:
	
	move $a0,$t3
	li $v0,1 
		syscall
li $v0,10
syscall
}


PB4 cauta numar
{
	.data
mesaj:	.asciiz "\ncauta\n"
mesaj2:	.asciiz "\nGasit!\n"
mesaj3:	.asciiz "\nNu l-am gasit gasit!\n"
n:		.word 0
vector:	.word 0
.text

main:
	li $v0,5 # read int
		syscall
	sw $v0,n # store n
	move $t0,$v0 
	mulo $t0,$t0,4
	move $a0,$t0 # calculate how many bytes
	li $v0,9
		syscall
	sw $v0,vector # valoarea lui vector e adresa unde se afla vectorul
	

	lw $t0,vector
	lw $t1,n
	mulo $t1,$t1,4 # adresa de sfarsit
	add $t1,$t0,$t1
	
FOR:
	beq $t0,$t1,END_FOR
	li $v0,5 
		syscall
	sw $v0,($t0)
	
	addi $t0,4
	j,FOR
END_FOR:
	
	la $a0,mesaj
	li $v0,4
		syscall
	
	li $v0,5 # citesc x
		syscall
	move $t7,$v0
	li $t6,0 # ok pt gasit sau nu
	
	lw $t0,vector
	lw $t1,n
	mulo $t1,$t1,4 # adresa de sfarsit
	add $t1,$t0,$t1
	
FOR1:
	beq $t0,$t1,END_FOR1
	lw $t2,($t0)
	bne $t2,$t7,SKIP
		li $t6,1
		j,END_FOR1
	SKIP:
	addi $t0,4
	j,FOR1
END_FOR1:
	beqz $t6,NU
	la $a0,mesaj2
	li $v0,4
		syscall
	j,END
NU:
	la $a0,mesaj3
	li $v0,4
		syscall
END:
	
li $v0,10
syscall
}

PB5 sort vector - doua foruri
{
.data
newline:	.asciiz "\n"
spatiu:	.asciiz " "

n:		.word 0
vector:	.word 0
.text

main:
	li $v0,5 # read int
		syscall
	sw $v0,n # store n
	move $t0,$v0 
	mulo $t0,$t0,4
	move $a0,$t0 # calculate how many bytes
	li $v0,9
		syscall
	sw $v0,vector # valoarea lui vector e adresa unde se afla vectorul
	
#citire
	lw $t0,vector
	lw $t1,n
	mulo $t1,$t1,4 # adresa de sfarsit
	add $t1,$t0,$t1
	
FOR:
	beq $t0,$t1,END_FOR
	li $v0,5 
		syscall
	sw $v0,($t0)
	
	addi $t0,4
	j,FOR
END_FOR:
#sfarsit citire

#sortarea
	lw $t0,vector
	lw $t3,n
	mulo $t3,$t3,4 
	add $t3,$t0,$t3 # adresa de sfarsit pt al doilea for
	sub $t1,$t3,4 # adresa de sfarsit pt primul for
	
FOR1:
	beq $t0,$t1,END_FOR1
	
	add $t2,$t0,4
	lw $t6,($t0) # v[i]
	
	FOR2:
	beq $t2,$t3,END_FOR2
		lw $t7,($t2) # v[j]
		ble $t6,$t7,NU
			xor $t6,$t6,$t7
			xor $t7,$t6,$t7
			xor $t6,$t6,$t7
			sw $t6,($t0)
			sw $t7,($t2)
		NU:
	addi $t2,4
	j,FOR2
	END_FOR2:
	
	addi $t0,4
	j,FOR1
END_FOR1:

#sfarsit sortare

#afisare
	lw $t0,vector
	lw $t1,n
	mulo $t1,$t1,4 # adresa de sfarsit
	add $t1,$t0,$t1
	
FOR3:
	beq $t0,$t1,END_FOR3
	lw $a0,($t0)
	li $v0,1
		syscall
	sw $v0,($t0)
	
	la $a0,spatiu
	li $v0,4
		syscall
	
	addi $t0,4
	j,FOR3
END_FOR3:
#sfarsit afisare

	la $a0,newline
	li $v0,4
		syscall
	
	
li $v0,10
syscall
}

}

MIPS2
{
PB1
{
.data
newline:	.asciiz "\n"

.text

main:
	li $v0,5
		syscall
	move $t1,$v0 # n
	li $t0,0 # i
	li $t5,1 # a
	li $t6,0 # b
FOR:
	beq $t0,$t1,END_FOR
	add $t7,$t5,$t6 # c
	move $t5,$t6
	move $t6,$t7
	
	move $a0,$t7
	li $v0,1
		syscall
	
	la $a0,newline
	li $v0,4
		syscall
	
	addi $t0,1
	j,FOR
END_FOR:
		
	la $a0,newline
	li $v0,4
		syscall
	
li $v0,10
syscall
}

PB2
{

}

PB3
{

}

PB4
{

}

PB5
{
.data
IsNotPrimeMessage:	.asciiz "Niuuuuu este prim!\n"
IsPrimeMessage:		.asciiz "Uite ca e prim, ce noroc pe tine\n"
.text

main:
	li $v0,5
		syscall
	move $t2,$v0 # n
	li $t0,2
	blt $t2,$t0,IsNotPrimeMessage # n<2
	div $t1,$t2,$t0 # l
	
	# n!=2 && n%2==0
	beq $t2,$t0,SKIP2VERIF
	
	div $t2,$t0		
	mfhi $t0
	beqz $t0,NOT_PRIME
SKIP2VERIF:

	# n!=3 && n%3==0
	li $t0,3
	beq $t2,$t0,SKIP3VERIF
	
	div $t2,$t0		
	mfhi $t0
	beqz $t0,NOT_PRIME
SKIP3VERIF:
	
	# acum restul numerelor prime sunt de forma 6k+-1
	li $t0,5
FOR:
	bge $t0,$t1,END_FOR
	
	# n%i==0
	div $t2,$t0
	mfhi $t5
	beqz $t5,NOT_PRIME
	
	# n%(i+2)==0
	addi $t0,2
	div $t2,$t0
	mfhi $t5
	beqz $t5,NOT_PRIME
	
	addi $t0,4
	j,FOR
END_FOR:	
	
	la $a0,IsPrimeMessage
	li $v0,4
		syscall
	j,END
NOT_PRIME:
	la $a0,IsNotPrimeMessage
	li $v0,4
		syscall
END:
li $v0,10
syscall
}

PB6
{

}

PB7
{

}

PB8
{

}

PB9
{

}

PB10
{

}

PB11
{

}

PB12
{

}

PB13
{

}

PB14
{

}

PB15
{

}

PB16
{

}

PB17
{

}

PB18
{

}

PB19
{

}

PB20
{

}

PB21
{

}

PB22
{

}

PB23
{

}

PB24
{

}

PB25
{

}

PB26
{

}

PB27
{

}

PB28
{

}

PB29
{

}

PB30
{

}

PB31
{

}

PB32
{

}

PB33
{

}


}

MIPS3
{
PB1
{

}

PB2
{

}

PB3
{

}

PB4
{

}

PB5
{

}

PB6
{

}

PB7
{

}

PB8
{

}

PB9
{

}

PB10
{

}

PB11
{

}

PB12
{

}

PB13
{

}

PB14
{

}

PB15
{

}

PB16
{

}

PB17
{

}

PB18
{

}

PB19
{

}

PB20
{

}

PB21
{

}

PB22
{

}

PB23
{

}

PB24
{

}

PB25
{

}

PB26
{

}

PB27
{

}

PB28
{

}


}