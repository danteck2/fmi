apeluri sistem\1 print int.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $v0,5 # read integer si pune in v0
			syscall
		move $a0,$v0
		li $v0,1 # print integer luandu-l din a0
			syscall
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\10 exit program.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\2 print float.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $v0,6 # read float si pune in f0
			syscall
		mov.s $f12,$f0
		li $v0,2 # print float luandu-l din a0
			syscall
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\3 print double.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $v0,7 # read double si-l salveaza in f0
			syscall
		mov.d $f12,$f0
		add.d $f12,$f12,$f12
		li $v0,3 # print double luandu-l din f12
			syscall
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\4.print string.s{
	.data
	# declaratii date
	MyString:	.asciiz ""
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		# tre a0=adresa start string, a1=numarul de caractere +1
		la $a0,MyString
		li $a1,5 # citeste un string de 4 caractere, nu te lasa mai mult sau mai putin
		
		li $v0,8 # read string si pune in a0 cu a1-1 caractere
			syscall
		
		li $v0,4 # print string luandu-l din a0
			syscall
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\5 read int.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $v0,5 # read integer si pune in v0
			syscall
		move $a0,$v0
		li $v0,1 # print integer luandu-l din a0
			syscall
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\6 read float.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $v0,6 # read float si pune in f0
			syscall
		mov.s $f12,$f0
		li $v0,2 # print float luandu-l din a0
			syscall
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\7 reading double.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $v0,7 # read double si-l salveaza in f0
			syscall
		mov.d $f12,$f0
		add.d $f12,$f12,$f12
		li $v0,3 # print double luandu-l din f12
			syscall
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\8.read string.s{
	.data
	# declaratii date
	MyString:	.asciiz ""
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		# tre a0=adresa start string, a1=numarul de caractere +1
		la $a0,MyString
		li $a1,5 # citeste un string de 4 caractere, nu te lasa mai mult sau mai putin
		
		li $v0,8 # read string si pune in a0 cu a1-1 caractere
			syscall
		
		li $v0,4 # print string luandu-l din a0
			syscall
		
	li $v0,10 #cum termini programul
	syscall
}

apeluri sistem\9 memory allocation.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $a0,16
		li $v0,9 # 
			syscall
		
		li $t0,0xffffffff
		sw $t0,($v0)
		sw $t0,4($v0) # merg doar multiplii de 4, un word are 4 bytes=>4*8 biti=32
		
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\add.s{
	.data
	# declaratii date
	x1:.word 1
	x2:.word 2
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 lw $t1,x1
	 lw $t2,x2
	 
	 add $t0,$t1,$t2 # t0=t1+t2 , ca pe int [â€“ 2^31 , 2^31 -1]
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\addi.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,16;
		addi $t0,$t1,16 
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\addiu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 addiu $t0,$t0,5
	 addiu $t0,$t0,5
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\addu.s{
	.data
	# declaratii date
	x1:.word 1
	x2:.word 2
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 lw $t1,x1
	 lw $t2,x2
	 
	 addu $t0,$t1,$t2 # t0=t1+t2 , ca pe unsigned [0 , 2^32 -1]
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\div.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,14
		li $t3,3
		div $t2,$t3
		
		mflo $t0 # move from LO aparent aici e rezultatul produsului
		mfhi $t1 # move from HI
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\dviu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,25
		li $t3,4
		divu $t2,$t3
		
		mflo $t0 # move from LO aparent aici e rezultatul produsului
		mfhi $t1 # move from HI
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\Hi LO instructions.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	#
	# Higher – registru special de înmultire/împartire în care se depoziteaza cei
	# mai semnificativi 32 de biti ai produsului, respectiv restul împartirii
	#
	# Lower - registru special de înmultire/împartire în care se depoziteaza cei mai
	# putini semnificativi 32 de biti ai produsului, respectiv câtul împartirii.
	# cod
		# HI restul impartirii
		# LO catul impartirii si rezultatul inmultirii
		
		li $t0,7
		li $t1,10
		
		mtlo $t0 # move to lo
		mthi $t1 # move to hi
		mflo $t1 # move from lo
		mfhi $t0 # move from hi
		
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\mult.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,4
		li $t3,3
		mult $t2,$t3
		
		mflo $t0 # move from LO aparent aici e rezultatul produsului
		mfhi $t1 # move from HI
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\multu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,3
		li $t3,2
		multu $t2,$t3
		
		mflo $t0 # move from LO aparent aici e rezultatul produsului
		mfhi $t1 # move from HI
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\sub.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,16;
		li $t2,6
		sub $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\subu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,0
		li $t2,0xffffffff
		subu $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\abs.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t2,10
	 li $t3,-10
	 
	 abs $t0,$t2
	 abs $t1,$t3
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\div.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,25
		li $t3,5
		div $t2,$t3
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\divu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t0,25
		li $t1,5
		divu $t2,$t3
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\mulo v1.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,8
		
		mulo $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\mulo v2.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		
		mulo $t0,$t1,8
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\mulou.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,8
		
		mulou $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\neg.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,-10
	 
	 neg $t0,$t1
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\negu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,-10
	 
	 negu $t0,$t1 #nu prea il inteleg?
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\rem.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,19
		li $t2,4
		
		rem $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\remu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,19
		li $t2,4
		
		remu $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\sub v1.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,16;
		sub $t0,$t1,6
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\sub v2.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,7
		sub $t0,4
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\subu v1.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,16;
		subu $t0,$t1,6
	
	li $v0,10 #cum termini programul
	syscall
}

arithmetic\pseudo\subu v2.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,7
		subu $t0,4
	
	li $v0,10 #cum termini programul
	syscall
}

compare\movn.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,1
		li $t2,3
		
		movn $t0,$t2,$t1 # t0=t2, daca t1!=0
		
	li $v0,10 #cum termini programul
	syscall
}

compare\movz.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,0
		li $t2,3
		
		movz $t0,$t2,$t1 # t0=t2, daca t1=0
		
	li $v0,10 #cum termini programul
	syscall
}

compare\seq.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,7
		li $t3,3
		li $t4,3
		
		seq $t0,$t2,$t3 # t0=(t2==t3)
		seq $t1,$t3,$t4 # 
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sge.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,7
		li $t3,7
		li $t4,3
		
		sge $t0,$t2,$t3 # t0=(t2>=t3)
		sge $t1,$t3,$t4 # 
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sgeu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,7
		li $t3,3
		li $t4,7
		
		sgeu $t0,$t2,$t3 # t0=(t2>=t3)
		sgeu $t1,$t2,$t4 # 
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sgt.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,7
		li $t2,3
		
		sgt $t0,$t1,$t2 # t0=(t1>t2)
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sgtu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,7
		li $t2,3
		
		sgtu $t0,$t1,$t2 # t0=(t1>t2)
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sle.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,3
		li $t3,7
		li $t4,7
		
		sle $t0,$t2,$t3 # t0=(t2<=t3)
		sle $t1,$t2,$t4 # 
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sleu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,3
		li $t3,7
		li $t4,7
		
		sleu $t0,$t2,$t3 # t0=(t2<=t3)
		sleu $t1,$t2,$t4 # 
		
	li $v0,10 #cum termini programul
	syscall
}

compare\slt.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,7
		li $t2,3
		
		slt $t0,$t1,$t2 # t0=(t1<t2) set on less then
		
	li $v0,10 #cum termini programul
	syscall
}

compare\slti.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,3
		li $t3,7
		
		slti $t0,$t2,3 # t0=(t2<3)
		slti $t1,$t2,8 # 
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sltiu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,7
		
		sltiu $t0,$t2,7 # t0=(t2<7)
		sltiu $t1,$t2,9 # 
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sltu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,3
		li $t3,7
		li $t4,7
		
		sltu $t0,$t2,$t3 # t0=(t2<t3)
		sltu $t1,$t2,$t4 # 
		
	li $v0,10 #cum termini programul
	syscall
}

compare\sne.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t2,7
		li $t3,3
		li $t4,7
		
		sne $t0,$t2,$t3 # t0=(t2!=t3)
		sne $t1,$t2,$t4 # 
		
	li $v0,10 #cum termini programul
	syscall
}

logic\and.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,12
		
		and $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

logic\andi.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		
		andi $t0,$t1,14
	
	li $v0,10 #cum termini programul
	syscall
}

logic\or.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,3
		li $t2,12
		
		or $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

logic\ori.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,3
		
		ori $t0,$t1,12
	
	li $v0,10 #cum termini programul
	syscall
}

logic\xor.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,2981
		li $t2,3
		li $t3,2981
		
		xor $t0,$t1,$t2
		xor $t0,$t0,$t3
	
	li $v0,10 #cum termini programul
	syscall
}

logic\xori.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,2981
		li $t2,3
		
		xor $t0,$t1,$t2
		xori $t0,$t0,2981
	
	li $v0,10 #cum termini programul
	syscall
}

logic\pseudo\and.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		
		and $t0,$t1,14
	
	li $v0,10 #cum termini programul
	syscall
}

logic\pseudo\nor.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,5
		li $t2,0xfffffff5
		
		nor $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

logic\pseudo\not.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,0xfffffffe
		
		not $t0,$t1
	
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\declarare date.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	ImSpace:	.space 12 # 12 bytes adica 3 word-uri
	
	ImByteChA:	.byte 'A' # 41
	ImByteChB:	.byte 'B' # 42
	ImByteChC:	.byte 'C' # 43
	ImByteChD:	.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	
	ImWord2:	.word 0x12345678 # 4 bytes a2999d
	mesaj:		.asciiz "Mesaj1\nLinie noua cu mesaj2"
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	
	
	
	 
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\move.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t0,17
		move $t1,$t0
		move $t2,$t1
		move $t3,$t2
		
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\load\la.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		la $t0,ImHalf
		la $t1,ImByte
		la $t2,ImWord
		la $t3,ImFloat
		la $t4,ImDouble
		la $t5,ImByteChA
		la $t6,ImByteChB
		la $t7,ImByteChC
		la $t8,ImByteChD
	 
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\load\lb.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		lb $t0,ImByteChA
		
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\load\lbu.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		lbu $t0,ImByteChA
		
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\load\lf.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		
		
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\load\lh.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		lh $t0,ImHalf
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\load\li.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t0,10 # $t0=10
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\load\lui.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		lui $t0,7 # 7 shiftat cu 16 biti la stanga si plasat in $t0
		
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\load\lw.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		lw $t0,ImWord
		
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\store\sb.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t0,17
		la $t1,ImByte
		sb $t0,($t1)
		
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\store\sh.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		la $t0,ImHalf
		li $t1,32
		sh $t1,($t0)
		
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\store\sw cu imm.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t0,0x12abcdef
		la $t1,ImWord
		sw $t0,4($t1) # adresa de la $t1 + 4 bytes
	li $v0,10 #cum termini programul
	syscall
}

operatiuni cu date\store\sw.s{
	.data
	# declaratii date
	ImHalf:		.half 16 # doi bytes
	ImByte:		.byte 8			# de ce astia doi mi-i pune in ordine inversa
	ImWord:		.word 666013 # 4 bytes a2999d
	ImFloat:	.float 12.3 # 32biti
	ImDouble:	.double 45.3 # 64biti
	
	ImByteChA:		.byte 'A' # 41
	ImByteChB:		.byte 'B' # 42
	ImByteChC:		.byte 'C' # 43
	ImByteChD:		.byte 'D' # 44 # secventa asta iti ilustreaza de ce par a fi inversa
	# testeaza .space
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t0,0x12abcdef
		la $t1,ImWord
		sw $t0,($t1)
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\cu zero\beqz.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,1
		
		beqz $t1,DA # sari daca egal cu zero
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\cu zero\bgez.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,0
		
		bgez $t1,DA #sari daca mai mare sau egal decat 0
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\cu zero\bgtz.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		
		bgtz $t1,DA #sari daca mai mare decat 0
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\cu zero\blez.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,0xffffffff
		
		blez $t1,DA # sari daca mai mic sau egal decat 0
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\cu zero\bltz.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,0xffffffff # asta-i -1
		
		bltz $t1,DA #sari daca mai mare decat zero
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\cu zero\bnez.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		
		bnez $t1,DA # sari daca diferit de zero
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\beq.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,4
		
		beq $t1,$t2,DA # sari daca egale
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\bge.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,4
		
		bge $t1,$t2,DA # sari daca mai mare sau egal
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\bgeu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,8
		li $t2,4
		
		bgeu $t1,$t2,DA # sari daca mai mare sau egal, unsigned
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\bgt.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,0xfffffffe #asta-i -2
		
		bgt $t1,$t2,DA # sari daca mai mare decat
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\ble.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,4
		
		ble $t1,$t2,DA # sari daca mai mic sau egal
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\bleu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,0xffffffff
		
		bleu $t1,$t2,DA # sari daca mai mic sau egal, unsigned
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\blt.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,4
		
		blt $t1,$t2,DA #sari daca mai mic
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\bltu.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,6
		
		bltu $t1,$t2,DA # sari daca mai mare, unsigned
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\intre doa valori\bne.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,12
		
		bne $t1,$t2,DA # sari daca diferite
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\salt (pseudo)\b.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		b,ETICHETA
		li $t0,-2
	ETICHETA:
		li $t0,0x22222222
		
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\salt (pseudo)\j.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		j,ETICHETA
		li $t0,-2
	ETICHETA:
		li $t0,0x22222222
		
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\salt (pseudo)\jal.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		jal,ETICHETA # jare la ETICHETA si pune in $ra adresa instructiunii urmatoare
		li $t0,-2
		j,END
	ETICHETA:
		li $t0,0x22222222
		move $t1,$ra
		j,$ra
	END:
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\salt (pseudo)\jalr.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		la $t2,ETICHETA
		jalr,$t1,$t2 # sare la $t2, si pune adresa urmatoarei instructiuni in $t1
		li $t0,-2
		j,END
	ETICHETA:
		li $t0,0x22222222
		jr,$t1
	END:
		
	li $v0,10 #cum termini programul
	syscall
}

ramificatie\salt (pseudo)\jr.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		la $t1,ETICHETA
		jr,$t1
		li $t0,-2
	ETICHETA:
		li $t0,0x22222222
		
	li $v0,10 #cum termini programul
	syscall
}

shiting bits\sll.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,0xffffffff
	 
	 sll $t0,$t1,4
	
	li $v0,10 #cum termini programul
	syscall
}

shiting bits\sllv.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,0xffffffff
	 li $t2,4
	 
	 sllv $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

shiting bits\sra.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,16
	 
	 sra $t0,$t1,4
	
	li $v0,10 #cum termini programul
	syscall
}

shiting bits\srav.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,16
	 # li $t1,0xfffffff0
	 
	 li $t2,4
	 
	 srav $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

shiting bits\srl.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,0xffffffff
	 
	 srl $t0,$t1,4
	
	li $v0,10 #cum termini programul
	syscall
}

shiting bits\srlv.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,0xffffffff
	 
	 srlv $t0,$t1,4
	
	li $v0,10 #cum termini programul
	syscall
}

shiting bits\pseudo\rol.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,0x53000000
	 li $t2,8
	 
	 rol $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

shiting bits\pseudo\ror.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
	 li $t1,0x00000053
	 li $t2,8
	 
	 ror $t0,$t1,$t2
	
	li $v0,10 #cum termini programul
	syscall
}

subrutine\bgezal.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,4
		
		beq $t1,$t2,DA
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

subrutine\bltzal.s{
	.data
	# declaratii date
	.text
	# cod
	main: # eticheta marcand punctul de start
	# cod
		li $t1,4
		li $t2,4
		
		beq $t1,$t2,DA
	#NU:
		li $t0,1
		j, END
	DA:
		li $t0,10
	END:
	
	li $v0,10 #cum termini programul
	syscall
}

