STRUCTURI DE CONTROL	

If{
blt $t0,$t1,ED1
		move $t4,$t0
		move $t0,$t1
		move $t1,$t4
ED1:
}

FOR{
la $t0,vector
	add $t1,$t0,40 #adresa de sfarsit
	li $t3,0 #suma
	
FOR:
	beq $t0,$t1,END_FOR
	lw $t2,($t0)
	
	add $t3,$t3,$t2
	
	addi $t0,4
	j,FOR
END_FOR:
}

READING A VECTOR WITH MEMORY ALOCATION{
n:		.word 0
vector:	.word 0

li $v0,5 # read int
		syscall
	sw $v0,n # store n
	move $t0,$v0 
	mulo $t0,$t0,4
	move $a0,$t0 # calculate how many bytes
	li $v0,9
		syscall
	sw $v0,vector # valoarea lui vector e adresa unde se afla vectorul
	

	lw $t0,vector
	lw $t1,n
	mulo $t1,$t1,4 # adresa de sfarsit
	add $t1,$t0,$t1
	
FOR:
	beq $t0,$t1,END_FOR
	li $v0,5 
		syscall
	sw $v0,($t0)
	
	addi $t0,4
	j,FOR
END_FOR:
}
